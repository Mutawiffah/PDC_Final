const express = require("express");
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Mock classification function
function classifyImage(image) {
  return { label: "cat", confidence: 0.92 };
}

// REST endpoint (if needed)
app.post("/classify", (req, res) => {
  const result = classifyImage(req.body.image);
  res.json(result);
});

app.listen(50051, () => {
  console.log("Mock Model Service running on port 50051");
});
