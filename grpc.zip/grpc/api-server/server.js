const express = require("express");
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Mock call to Model Service
function callModelService(image) {
  return { label: "cat", confidence: 0.92 };
}

app.post("/uploadImage", (req, res) => {
  const image = req.body.image; 
  const result = callModelService(image);
  const response = {
    ...result,
    endToEndMs: Math.floor(Math.random() * 10) + 1
  };
  res.json(response);
});

app.listen(6000, () => {
  console.log("API Service running on port 6000");
});
