const axios = require("axios");

// Simulate sending 1 image
async function sendImage(imageName) {
  const response = await axios.post("http://localhost:6000/uploadImage", {
    image: imageName
  });
  console.log("Response:", response.data);
}

async function main() {
  console.log("Uploading single image...");
  await sendImage("image1.jpg");

  console.log("\nUploading batch of 5 images...");
  for (let i = 1; i <= 5; i++) {
    await sendImage(`image${i}.jpg`);
  }
}

main();
